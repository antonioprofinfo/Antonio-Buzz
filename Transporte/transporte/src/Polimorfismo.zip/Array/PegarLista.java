package Array;

public class PegarLista extends Listar{

    

    public PegarLista(String nome, String curso) {
        super(nome, curso);
    
    }

   

    public void desconto(){
        System.out.println("teste");
    }

}