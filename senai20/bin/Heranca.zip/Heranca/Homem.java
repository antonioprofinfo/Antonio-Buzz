package Heranca;

public class Homem extends Humano {
    //Humano -> SuperClasse
    //Homem -> SubClasse de Humano
     String biotipo;


    public Homem(String nome, int idade, float peso){
        super(nome, idade, peso);
    }

    

}
